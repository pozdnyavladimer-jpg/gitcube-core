# Quickstart

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
gitcube analyze .
```

Analyze another path:
```bash
gitcube analyze /path/to/repo
```
